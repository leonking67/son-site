# İlker Kabacık — Premium FinTech / DeFi Personal Site

Next.js 14 (App Router) + TypeScript + Tailwind.
Premium mavi/gold tema, PayUSDT vurgusu ve Astro Leadership bölümü ile.

## Geliştirme
```bash
npm i
npm run dev
# http://localhost:3000
```

## Deploy (Vercel)
- Repo'yu GitHub'a pushla
- Vercel -> New Project -> Import from GitHub -> Deploy
- Domain: Settings -> Domains -> ilkerkabacik.com